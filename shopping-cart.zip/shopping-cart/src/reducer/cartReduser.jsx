export const cartReduser = (state, action) => {
  const { type, paylod } = action;
  switch (type) {
    case "ADD_to_CART":
      return { ...state, cartList: paylod.products };
    case "REMOVE_FROM_CART":
      return { ...state, cartList: paylod.products };
    case "UPDATE_TOTAL":
      return { ...state, total: paylod.total };

    default:
      throw new Error("No case found in cartReducer");
  }
};
