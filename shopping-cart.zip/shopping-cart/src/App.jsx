import { Cart } from "./components/Cart";
import "./App.css";
export default function App() {
  return (
    <>
      <Cart />
    </>
  );
}
