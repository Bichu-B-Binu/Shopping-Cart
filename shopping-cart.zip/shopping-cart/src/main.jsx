import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Routers } from "react-router-dom";
// eslint-disable-next-line no-unused-vars
import App from "./App";
import "./index.css";
import { ContextProvider } from "./cartContext/CartContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Routers>
      <ContextProvider>
        <App />
      </ContextProvider>
    </Routers>
  </React.StrictMode>
);
