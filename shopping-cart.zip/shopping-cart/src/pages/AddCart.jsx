/* eslint-disable react/jsx-key */
/* eslint-disable react/prop-types */
import styles from "../pages/AddCart.module.css";
import { useCart } from "../cartContext/CartContext";
export const AddCart = ({ cartItem }) => {
  const { total, removeCart, cartList } = useCart();
  // console.log(total);

  return (
    <>
      <div className="text-center my-5">
        <h2 className={styles.heading}>
          Cart Items: {cartList.length}/${total}
        </h2>
        {cartList.map((item) => (
          <div key={item.id} className={`${styles.cartItems}  mb-2`}>
            <div className=" d-flex align-items-center justify-content-between p-2 ">
              <img
                src={item.image}
                alt="Cart image"
                className={styles.cartImages}
              />
              <h5>{item.name}</h5>
              <h5>{item.price}$</h5>
              <button
                onClick={() => removeCart(item)}
                className="btn btn-danger rounded-2"
              >
                Romove
              </button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};
