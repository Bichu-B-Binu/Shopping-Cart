// import styles from "./CartList.module.css";
import Container from "react-bootstrap/Container";
// import Row from "react-bootstrap/Row";
// import Col from "react-bootstrap/Col";
import { CartCard } from "./CartCard";
import { AddCart } from "../pages/AddCart";
import { Route, Routes } from "react-router-dom";
export const CartList = () => {
  const items = [
    {
      id: 1001,
      name: "iClever Kids Headphones for Girls Gift Over Ear Headphones",
      price: 149,
      image: "/assets/Head-phone-1.jpg",
    },
    {
      id: 1002,
      name: "HAMMER Bash 2.0 Over The Ear Wireless Bluetooth Headphones with Mic",
      price: 200,
      image: "/assets/Head-phone-2.jpg",
    },
    {
      id: 1003,
      name: "Zeb-Jet Pro",
      price: 19,
      image: "/assets/Head-phone-3.jpg",
    },
    {
      id: 1004,
      name: "Noise Newly Launched Three Wireless On-Ear Headphones with 70H Playtime",
      price: 399,
      image: "/assets/Head-phone-4.jpg",
    },
    {
      id: 1005,
      name: "The 4 Best Bluetooth Wireless Headphones of 2024 | Reviews by Wirecutter",
      price: 190,
      image: "/assets/Head-phone-5.jpg",
    },
    {
      id: 1006,
      name: "Philips TAH8506BK wireless headphones",
      price: 299,
      image: "/assets/Head-phone-6.jpg",
    },
  ];

  const cartItem = [
    // {
    //   id: 1003,
    //   name: "Zeb-Jet Pro",
    //   price: 19,
    //   image: "/assets/Head-phone-3.jpg",
    // },
    // {
    //   id: 1004,
    //   name: "Noise Newly Launched Three Wireless On-Ear Headphones with 70H Playtime",
    //   price: 399,
    //   image: "/assets/Head-phone-4.jpg",
    // },
  ];
  return (
    <>
      <div className=" container mt-5 d-flex align-items-center justify-content-center">
        <Container>
          <Routes>
            <Route path="/" element={<CartCard items={items} />} />
            <Route path="cart" element={<AddCart cartItem={cartItem} />} />
          </Routes>
        </Container>
      </div>
    </>
  );
};
