import { CartList } from "./CartList";
import { Header } from "./Header";

export const Cart = () => {
  return (
    <>
      <Header />
      <CartList />
    </>
  );
};
