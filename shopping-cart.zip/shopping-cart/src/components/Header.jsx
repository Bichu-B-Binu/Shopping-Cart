import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import styles from "./Header.module.css";
import { useNavigate } from "react-router-dom";
export const Header = () => {
  const navigate = useNavigate();
  return (
    <>
      <Navbar expand="lg" fixed="top" bg="light" className={styles.line}>
        <Container>
          <img
            src="/assets/shopping-cart.webp"
            alt="icon"
            className={styles.image}
          />
          <Navbar.Brand href="#home">Shopping-cart</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="m-auto w-50">
              <Nav.Link onClick={() => navigate("/")} className={styles.items}>
                Home
              </Nav.Link>

              <Nav.Link
                onClick={() => navigate("cart")}
                className={styles.items}
              >
                Cart
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
          <h4>Cart:2</h4>
        </Container>
      </Navbar>
    </>
  );
};
