/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-key */
import Card from "react-bootstrap/Card";
import { useCart } from "../cartContext/CartContext";
import styles from "./CartCard.module.css";
export const CartCard = ({ items }) => {
  const { addToCart } = useCart();
  // const handeladd = (item) => {
  //   addToCart(item);
  // console.log(cartList);
  // };

  return (
    <>
      <div className={styles.fullBody}>
        <div className={`${styles.bodyCards}`}>
          <div className="row">
            {items.map((item) => (
              <div key={item.id} className="col-4">
                <Card className={`${styles.cards} mb-4`}>
                  <Card.Body className=" text-center d-flex align-items-center justify-content-between flex-column">
                    <img
                      src={item.image}
                      alt="headphone"
                      className={styles.images}
                    />
                    <h5 className=" mt-4">{item.name}</h5>
                    <div className=" d-flex align-items-center justify-content-between w-100">
                      <h5>{item.price}$</h5>
                      <button
                        onClick={() => addToCart(item)}
                        className="btn btn-primary"
                      >
                        Add To Cart
                      </button>
                    </div>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};
