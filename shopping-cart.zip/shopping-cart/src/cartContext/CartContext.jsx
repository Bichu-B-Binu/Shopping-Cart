/* eslint-disable react-refresh/only-export-components */
/* eslint-disable no-undef */
/* eslint-disable react/prop-types */
import { useReducer } from "react";
import { createContext, useContext } from "react";
import { cartReduser } from "../reducer/cartReduser";
const intialValue = {
  cartList: [],
  total: 0,
};

const CartContext = createContext(intialValue);

// console.log(CartContext);
export const ContextProvider = ({ children }) => {
  // eslint-disable-next-line no-undef
  const [state, dispatch] = useReducer(cartReduser, intialValue);

  const addToCart = (products) => {
    // console.log(products.price);
    const updatedCart = state.cartList.concat(products);
    console.log(products);

    updateTotal(updatedCart);
    dispatch({
      type: "ADD_to_CART",
      paylod: {
        products: updatedCart,
      },
    });
  };
  const removeCart = (product) => {
    const updatedCart = state.cartList.filter(
      (cartList) => cartList.id !== product.id
    );
    updateTotal(updatedCart);
    dispatch({
      type: "REMOVE_FROM_CART",
      paylod: {
        products: updatedCart,
      },
    });
  };

  const updateTotal = (products) => {
    let total = 0;
    products.forEach((product) => (total = total + product.price));
    dispatch({
      type: "UPDATE_TOTAL",
      paylod: {
        total,
      },
    });
    // return console.log(products);
  };
  // updateTotal();

  const value = {
    cartList: state.cartList,
    total: state.total,
    addToCart,
    removeCart,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

export const useCart = () => {
  const context = useContext(CartContext);
  // console.log(context);
  return context;
};
